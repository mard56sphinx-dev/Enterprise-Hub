import { CategoryType } from '../types/database';

export interface NERResult {
  category: CategoryType;
  detectedPhone?: string;
  familyId?: string;
  serialCode?: string;
  firstName?: string;
  secondName?: string;
  thirdName?: string;
  fourthName?: string;
  tribalName?: string;
  fullName?: string;
  birthYear?: string;
  age?: string;
  occupation?: string;
  governorate?: string;
  district?: string;
  subDistrict?: string;
  neighborhood?: string;
  alley?: string;
  house?: string;
  street?: string;
  landmark?: string;
  nationalId?: string;
  civilId?: string;
  passportNo?: string;
  motherName?: string;
  spouseName?: string;
  militaryRank?: string;
  unit?: string;
  battalion?: string;
  brigade?: string;
  charge?: string;
  accountNo?: string;
  iban?: string;
  salary?: string;
  university?: string;
  college?: string;
  graduationYear?: string;
}

// -------------------------------------------------------------
// INSTITUTIONAL, CIVIL, SECURITY & FIELD HEADER DICTIONARY
// -------------------------------------------------------------

export const ARABIC_GOVERNORATES = [
  'بغداد', 'النجف', 'نينوى', 'البصرة', 'أربيل', 'السليمانية', 'دهوك', 'بابل',
  'كربلاء', 'كركوك', 'الأنبار', 'ذي قار', 'ديالي', 'صلاح الدين', 'القادسية',
  'ميسان', 'المثنى', 'واسط', 'الموصل', 'الديوانية',
  // Syria
  'دمشق', 'ريف دمشق', 'حلب', 'حمص', 'حماة', 'اللاذقية', 'طرطوس', 'إدلب',
  'دير الزور', 'الحسكة', 'الرقة', 'درعا', 'السويداء', 'القنيطرة',
  // Egypt
  'القاهرة', 'الجيزة', 'الإسكندرية', 'الدقهلية', 'الشرقية', 'القليوبية', 'المنوفية',
  'الغربية', 'البحيرة', 'الإسماعيلية', 'أسيوط', 'سوهاج', 'قنا', 'أسوان',
  // Saudi
  'الرياض', 'مكة المكرمة', 'المدينة المنورة', 'الشرقية', 'القصيم', 'عسير', 'تبوك',
  'حائل', 'الجوف', 'جازان', 'نجران', 'الباحة', 'الحدود الشمالية',
  // Jordan
  'عمان', 'إربد', 'الزرقاء', 'المفرق', 'السلط', 'الكرك', 'مأدبا', 'جرش', 'عجلون', 'العقبة'
];

export const PERSONAL_NAME_HEADERS = [
  'الاسم', 'الاسم الكامل', 'الاسم الثلاثي', 'الاسم الرباعي', 'اسم المستفيد',
  'اسم المشترك', 'الاسم الاول', 'الاسم الثاني', 'الاسم الثالث', 'الاسم الرابع',
  'اسم الاب', 'اسم الجد', 'اسم والد الجد', 'اللقب', 'العشيرة', 'الكنية',
  'اسم الام', 'اسم الام الثلاثي', 'اسم الزوج', 'اسم الزوجة', 'عدد الابناء',
  'عدد أفراد العائلة', 'الوالدين', 'المعيل', 'اعالة الاخرين', 'صلة القرابة',
  'الحالة الاجتماعية', 'الموقف العائلي',
  'first name', 'father name', 'grandfather name', 'great grandfather',
  'tribal/family', 'mother\'s name', 'full name', 'spouse name', 'family count', 'relation'
];

export const CIVIL_DOC_HEADERS = [
  'تاريخ الولادة', 'سنة الولادة', 'مكان التولد', 'محل الولادة', 'رقم الهوية',
  'رقم الاحوال المدنية', 'رقم السجل', 'رقم الصحيفة', 'الرقم الوطني', 'الموحدة',
  'رقم البطاقة الموحدة', 'جهة الاصدار', 'تاريخ الاصدار', 'تاريخ النفاذ', 'جنسية',
  'جواز السفر', 'رقم الجواز', 'نوع الجواز', 'الفيزا', 'الرقم الاحصائي', 'رقم القرار',
  'تاريخ منح اول راتب', 'تاريخ القطع', 'رقم العقد', 'تاريخ العقد', 'تاريخ التعويض',
  'نسبة العجز', 'الصنف', 'التعزية', 'رقم الكتاب', 'تاريخ الكتاب',
  'dob', 'year of birth', 'place of birth', 'national id', 'civil id', 'book no',
  'page no', 'passport no', 'issue date', 'expiry date', 'person_id_hr', 'hr_no', 'hr_qualification'
];

export const ADDRESS_HEADERS = [
  'المحافظة', 'القضاء', 'الناحية', 'الحي', 'المنطقة', 'المحلة', 'الزقاق',
  'الدار', 'الشارع', 'مجاور', 'نقطة دالة', 'السكن', 'العنوان', 'العنوان التفصيلي',
  'البريد المحلي', 'رقم البريد', 'الصندوق البريدي', 'الموقع', 'العمارة', 'الشقة', 'الطابق',
  'address', 'governorate', 'district', 'street', 'house no', 'zip code', 'place of detention'
];

export const MILITARY_SECURITY_HEADERS = [
  'اسم الارهابي الصريح', 'الرقم العسكري', 'الرتبة', 'ش الركن', 'التشكيل', 'التشكيل الأعلى',
  'الفوج', 'اللواء', 'الفرقة', 'القيادة', 'الوحدة', 'الملحق', 'المرقا لها',
  'الجانب الأقدم', 'الجانب الأحدث', 'اسم التشكيل', 'نوع الترقية', 'الرمز السري',
  'الرقم السري', 'العميل', 'العنوان او مكان العمل', 'الملاحظات', 'الموقف', 'السجن',
  'رقم القضية', 'التهمة', 'المادة القانونية', 'تاريخ الاعتقال', 'جهة التحقيق',
  'اسم القاضي', 'المحكمة', 'صادر عن', 'الواردة',
  'military id', 'rank', 'unit', 'battalion', 'brigade', 'division', 'hr_rank', 'hr_name', 'hr_unit', 'charge', 'court case', 'case no'
];

export const FINANCIAL_HEADERS = [
  'رقم الحساب', 'رقم البطاقة المصرفية', 'ماستر كارد', 'فيزا كارد', 'كي كارد',
  'الـ iban', 'iban', 'الفرع المصرفي', 'اسم المصرف', 'الراتب', 'الراتب الكلي',
  'الراتب الاسمي', 'المستحقات', 'المبلغ', 'الاستقطاع', 'القرض', 'نوع القرض',
  'رقم المعاملة المالية', 'التمويل',
  'account no', 'card no', 'bank name', 'salary', 'net salary', 'amount', 'transaction id'
];

export const EMPLOYMENT_EDUCATION_HEADERS = [
  'الوظيفة', 'الدرجة الوظيفية', 'العنوان الوظيفي', 'القسم', 'الشعبة', 'المديرية',
  'الوزارة', 'الرقم التقاعدي', 'الصفة', 'اسم الخريج', 'الجامعة', 'الكلية',
  'المعهد', 'المدرسة', 'الدور', 'المعدل', 'سنة التخرج', 'نوع الدراسة',
  'التخصص', 'الاختصاص', 'الحالة الدراسية', 'رقم الطالب',
  'job title', 'position', 'department', 'directorate', 'ministry', 'pension no',
  'graduate name', 'university', 'college', 'gpa', 'graduation year', 'student id'
];

export const HEALTHCARE_SOCIAL_HEADERS = [
  'المستشفى', 'المركز الصحي', 'العيادة', 'اسم الطبيب', 'التشخيص', 'فصيلة الدم',
  'نسبة العجز', 'قسم الحماية', 'الحماية الاجتماعية', 'الرعاية الاجتماعية',
  'الشهداء والاسرى', 'ذوي الاحتياجات الخاصة', 'مساعدات انسانية', 'تعليم', 'صحة',
  'خدمات عامة', 'زراعي', 'شؤون المرأة', 'ثقافة', 'اعلام', 'شباب', 'تنمية مستدامة',
  'فن', 'حقوق الانسان', 'بيئة', 'تطوير اقتصادي', 'اطفال وايتام', 'ديمقراطية'
];

// Combine all noise headers to strip during un-structured token parsing
export const ALL_DICTIONARY_NOISE = [
  ...PERSONAL_NAME_HEADERS,
  ...CIVIL_DOC_HEADERS,
  ...ADDRESS_HEADERS,
  ...MILITARY_SECURITY_HEADERS,
  ...FINANCIAL_HEADERS,
  ...EMPLOYMENT_EDUCATION_HEADERS,
  ...HEALTHCARE_SOCIAL_HEADERS,
  '||', '-', '/', ',', ';', ':', '='
];

// -------------------------------------------------------------
// CARRIER PREFIX VALIDATION & ROUTING ENGINE
// -------------------------------------------------------------

export function determineCarrierCategory(
  detectedPhone: string | undefined,
  targetDatabase?: string
): CategoryType {
  const targetLower = (targetDatabase || '').toLowerCase();

  // 1. Target Upload Enforcement
  if (targetLower.includes('آسيا') || targetLower.includes('asia')) return 'asia';
  if (targetLower.includes('زين') || targetLower.includes('zain')) return 'zain';
  if (targetLower.includes('كورك') || targetLower.includes('korek')) return 'korek';
  if (targetLower.includes('سيريتل') || targetLower.includes('syriatel')) return 'syriatel';
  if (targetLower.includes('mtn')) return 'mtn';

  // 2. Universal Prefix Routing (Unassigned/Global Uploads)
  if (!detectedPhone) return 'other';

  const cleanPhone = detectedPhone.replace(/\D/g, '');

  // AsiaCell: ^(\+?964|0)?77\d{8}$ (Starts with 077 / 77)
  if (/^(964)?0?77\d{8}$/.test(cleanPhone) || /^77\d{8}$/.test(cleanPhone)) {
    return 'asia';
  }

  // Zain Iraq: ^(\+?964|0)?7[89]\d{8}$ (Starts with 078 / 079 / 78 / 79)
  if (/^(964)?0?7[89]\d{8}$/.test(cleanPhone) || /^7[89]\d{8}$/.test(cleanPhone)) {
    return 'zain';
  }

  // Korek Telecom: ^(\+?964|0)?75\d{8}$ (Starts with 075 / 75)
  if (/^(964)?0?75\d{8}$/.test(cleanPhone) || /^75\d{8}$/.test(cleanPhone)) {
    return 'korek';
  }

  // SyriaTel: 093, 094, 095, 096, +96393...
  if (/^(963)?0?9[3456]\d{7}$/.test(cleanPhone)) {
    return 'syriatel';
  }

  // MTN Syria: 098, 099, 091, 092, +96398...
  if (/^(963)?0?9[8912]\d{7}$/.test(cleanPhone)) {
    return 'mtn';
  }

  // International Format (>10 digits with country code)
  if (cleanPhone.length >= 10) {
    return 'international';
  }

  return 'other';
}

// -------------------------------------------------------------
// SMART UNSTRUCTURED TOKENIZER & HEURISTIC PARSER
// -------------------------------------------------------------

export function parseNERFromRecord(
  data: Record<string, any>,
  targetDatabase?: string
): NERResult {
  const result: NERResult = {
    category: 'other'
  };

  const findVal = (keys: string[]): string | undefined => {
    for (const [k, v] of Object.entries(data)) {
      if (v === null || v === undefined) continue;
      const lowerKey = k.toLowerCase().trim();
      if (keys.some((p) => lowerKey.includes(p.toLowerCase()))) {
        const valStr = String(v).trim();
        if (valStr) return valStr;
      }
    }
    return undefined;
  };

  // 1. Structured key-value matching first
  result.familyId = findVal(['familyid', 'family_id', 'عائل', 'عائله', 'رقم العائلة']);
  result.serialCode = findVal(['serial', 'code', 'تسلسلي', 'كود', 'الرقم الوطني', 'الرقم_التسلسلي']);
  result.firstName = findVal(['firstname', 'first_name', 'الاول', 'أول', 'اسم المستفيد']);
  result.secondName = findVal(['secondname', 'second_name', 'الثاني', 'ثاني', 'اسم الاب']);
  result.thirdName = findVal(['thirdname', 'third_name', 'الثالث', 'ثالث', 'اسم الجد']);
  result.fourthName = findVal(['fourthname', 'fourth_name', 'الرابع', 'اسم والد الجد']);
  result.tribalName = findVal(['tribal', 'family', 'اللقب', 'العشيرة']);
  result.birthYear = findVal(['birth', 'mowalad', 'مواليد', 'تولد', 'سنة الولادة']);
  result.age = findVal(['age', 'عمر', 'العمر']);
  result.occupation = findVal(['job', 'occupation', 'وظيفة', 'وظيفه', 'مهنة', 'عمل']);
  result.governorate = findVal(['governorate', 'province', 'محافظة', 'محافظه']);
  result.district = findVal(['district', 'قضاء']);
  result.subDistrict = findVal(['subdistrict', 'ناحية', 'ناحيه']);
  result.neighborhood = findVal(['neighborhood', 'محلة', 'محله', 'حي']);
  result.alley = findVal(['alley', 'زقاق']);
  result.house = findVal(['house', 'دار', 'بيت']);
  result.nationalId = findVal(['national_id', 'موحدة', 'بطاقة موحدة', 'الرقم الوطني']);
  result.militaryRank = findVal(['rank', 'رتبة', 'الرتبة']);
  result.accountNo = findVal(['account', 'حساب', 'رقم الحساب']);
  result.iban = findVal(['iban', 'اييبان']);

  // Combine raw text string for unstructured heuristic parsing
  const rawValues = Object.values(data)
    .filter((v) => v !== null && v !== undefined)
    .map((v) => String(v).trim())
    .join(' ');

  // 2. Phone Extraction
  const phoneMatch = rawValues.match(/(?:\+?\d{1,4}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}/);
  if (phoneMatch) {
    const candidate = phoneMatch[0].trim();
    if (candidate.replace(/\D/g, '').length >= 7) {
      result.detectedPhone = candidate;
    }
  }

  // Determine Carrier Category based on Target Upload & Universal Prefix Routing
  result.category = determineCarrierCategory(result.detectedPhone, targetDatabase);

  // 3. Birth Year & Age Extraction
  if (!result.birthYear) {
    const yrMatch = rawValues.match(/\b(19\d{2}|20[0-2]\d)\b/);
    if (yrMatch) {
      result.birthYear = yrMatch[1];
    }
  }

  if (result.birthYear && !result.age) {
    const yr = parseInt(result.birthYear, 10);
    if (!isNaN(yr) && yr > 1900 && yr <= 2026) {
      result.age = String(2026 - yr);
    }
  }

  // 4. Governorate Extraction from Geographic Dictionary
  if (!result.governorate) {
    for (const gov of ARABIC_GOVERNORATES) {
      if (rawValues.includes(gov)) {
        result.governorate = gov;
        break;
      }
    }
  }

  // 5. Abbreviated Geographic Markers Extraction [م, ز, د, ح, أ, ش, ق, ن]
  // e.g. "م 102 ز 12 د 5" or "م. 105 ز. 3"
  if (!result.neighborhood) {
    const mMatch = rawValues.match(/(?:م|محلة|حي)\s*\.?\s*(\d+|[\u0621-\u064A]{3,})/i);
    if (mMatch) result.neighborhood = mMatch[1];
  }

  if (!result.alley) {
    const zMatch = rawValues.match(/(?:ز|زقاق)\s*\.?\s*(\d+|[\u0621-\u064A]{3,})/i);
    if (zMatch) result.alley = zMatch[1];
  }

  if (!result.house) {
    const dMatch = rawValues.match(/(?:د|دار|بيت)\s*\.?\s*(\d+|[\u0621-\u064A]{3,})/i);
    if (dMatch) result.house = dMatch[1];
  }

  if (!result.district) {
    const qMatch = rawValues.match(/(?:ق|قضاء)\s*\.?\s*([\u0621-\u064A]{3,})/i);
    if (qMatch) result.district = qMatch[1];
  }

  if (!result.subDistrict) {
    const nMatch = rawValues.match(/(?:ن|ناحية|ناحيه)\s*\.?\s*([\u0621-\u064A]{3,})/i);
    if (nMatch) result.subDistrict = nMatch[1];
  }

  // 6. Name Token Assembly
  if (!result.firstName) {
    // Strip phone, year, governorate, headers, noise to extract full name tokens
    let cleaned = rawValues;
    if (result.detectedPhone) cleaned = cleaned.replace(result.detectedPhone, '');
    if (result.birthYear) cleaned = cleaned.replace(result.birthYear, '');

    ALL_DICTIONARY_NOISE.forEach((header) => {
      cleaned = cleaned.replaceAll(header, ' ');
    });

    // Keep only Arabic & English letter tokens
    cleaned = cleaned.replace(/[^a-zA-Z\u0621-\u064A\s]/g, ' ').trim();

    const words = cleaned
      .split(/\s+/)
      .filter((w) => w.length >= 2 && !ARABIC_GOVERNORATES.includes(w));

    if (words.length > 0) {
      result.firstName = words[0];
      if (words.length > 1) result.secondName = words[1];
      if (words.length > 2) result.thirdName = words[2];
      if (words.length > 3) result.fourthName = words[3];
      result.fullName = words.slice(0, 4).join(' ');
    }
  } else {
    result.fullName = [result.firstName, result.secondName, result.thirdName, result.fourthName]
      .filter(Boolean)
      .join(' ');
  }

  return result;
}
