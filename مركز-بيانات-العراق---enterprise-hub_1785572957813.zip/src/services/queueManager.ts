import { QueueItem, ProcessingMetrics, ScopeType } from '../types/database';
import { db, formatBytes, formatDuration, addAuditLog } from './db';
import { parseFile } from './parsers';

export type QueueListener = (
  metrics: ProcessingMetrics | null,
  queueItems: QueueItem[]
) => void;

class ProcessingQueueManager {
  private queue: QueueItem[] = [];
  private isProcessing = false;
  private listeners: QueueListener[] = [];
  private timerId: any = null;
  private currentActiveIndex = -1;
  private activeWorker: Worker | null = null;

  public subscribe(listener: QueueListener): () => void {
    this.listeners.push(listener);
    this.notify();
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    const activeItem =
      this.currentActiveIndex >= 0 ? this.queue[this.currentActiveIndex] : null;

    let metrics: ProcessingMetrics | null = null;
    if (activeItem && activeItem.status === 'processing') {
      const percent =
        activeItem.totalBytes > 0
          ? Math.min(
              100,
              Math.round((activeItem.processedBytes / activeItem.totalBytes) * 100)
            )
          : 0;

      metrics = {
        currentFileName: activeItem.file.name,
        processedBytes: activeItem.processedBytes,
        totalBytes: activeItem.totalBytes,
        extractedRecords: activeItem.extractedRecordsCount,
        elapsedSeconds: activeItem.elapsedSeconds,
        percent,
        queueLength: this.queue.length,
        activeItemIndex: this.currentActiveIndex,
        statusText: `جاري تحليل: ${activeItem.file.name} (${activeItem.targetDatabase})`
      };
    }

    const itemsCopy = [...this.queue];
    this.listeners.forEach((l) => l(metrics, itemsCopy));
  }

  public enqueueFiles(
    files: FileList | File[],
    targetDatabase = 'قاعدة بيانات العراق',
    scope: ScopeType = 'local',
    country = 'العراق'
  ): void {
    const fileArray = Array.from(files);
    fileArray.forEach((file) => {
      const item: QueueItem = {
        id: Math.random().toString(36).substring(2, 9),
        file,
        status: 'pending',
        processedBytes: 0,
        totalBytes: file.size,
        extractedRecordsCount: 0,
        elapsedSeconds: 0,
        targetDatabase,
        scope,
        country
      };
      this.queue.push(item);
    });

    this.notify();

    if (!this.isProcessing) {
      this.processNextInQueue();
    }
  }

  // Live Queue Control 1: Pause Queue Item
  public pauseItem(id: string): void {
    const item = this.queue.find((q) => q.id === id);
    if (!item) return;

    if (item.status === 'processing') {
      item.status = 'paused';
      if (this.activeWorker) {
        this.activeWorker.terminate();
        this.activeWorker = null;
      }
      this.notify();
    } else if (item.status === 'pending') {
      item.status = 'paused';
      this.notify();
    }
  }

  // Live Queue Control 2: Resume Queue Item
  public resumeItem(id: string): void {
    const item = this.queue.find((q) => q.id === id);
    if (!item) return;

    if (item.status === 'paused') {
      item.status = 'pending';
      this.notify();
      if (!this.isProcessing) {
        this.processNextInQueue();
      }
    }
  }

  // Live Queue Control 3: Cancel/Remove Queue Item
  public async cancelItem(id: string): Promise<void> {
    const index = this.queue.findIndex((q) => q.id === id);
    if (index === -1) return;

    const item = this.queue[index];

    if (item.status === 'processing' && this.activeWorker) {
      this.activeWorker.terminate();
      this.activeWorker = null;
    }

    if (item.fileId) {
      try {
        await db.files.delete(item.fileId);
        await db.records.where('fileId').equals(item.fileId).delete();
      } catch (err) {
        console.warn('Error deleting records for cancelled item:', err);
      }
    }

    this.queue.splice(index, 1);
    this.notify();

    if (this.currentActiveIndex === index) {
      this.currentActiveIndex = -1;
      this.processNextInQueue();
    }
  }

  private async processNextInQueue(): Promise<void> {
    const pendingIndex = this.queue.findIndex((item) => item.status === 'pending');

    if (pendingIndex === -1) {
      this.isProcessing = false;
      this.currentActiveIndex = -1;
      this.stopTimer();
      this.notify();
      return;
    }

    this.isProcessing = true;
    this.currentActiveIndex = pendingIndex;
    const item = this.queue[pendingIndex];

    item.status = 'processing';
    item.startTime = Date.now();
    item.elapsedSeconds = 0;
    this.startTimer();
    this.notify();

    let fileId: number | null = null;

    try {
      const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
      fileId = await db.files.add({
        fileName: item.file.name,
        fileSizeBytes: item.file.size,
        fileSize: formatBytes(item.file.size),
        fileType: item.file.type || item.file.name.split('.').pop()?.toUpperCase() || 'FILE',
        uploadTimestamp: timestamp,
        parseDuration: 'تحت المعالجة...',
        recordCount: 0,
        targetDatabase: item.targetDatabase,
        scope: item.scope,
        country: item.country
      });

      item.fileId = fileId;

      const startTime = Date.now();

      // Execute parsing with progress callbacks
      const extractedCount = await parseFile(
        item.file,
        fileId,
        {
          targetDatabase: item.targetDatabase,
          scope: item.scope,
          country: item.country
        },
        (processedBytes, currentRecordCount) => {
          // Check if item was paused during parsing
          if ((item.status as any) === 'paused') {
            return;
          }
          item.processedBytes = processedBytes;
          item.extractedRecordsCount = currentRecordCount;
          this.notify();
        }
      );

      // If user paused while running, return early without marking completed
      if ((item.status as any) === 'paused') {
        return;
      }

      const endTime = Date.now();
      const durationMs = endTime - startTime;
      const durationText = formatDuration(durationMs);

      await db.files.update(fileId, {
        parseDuration: durationText,
        recordCount: extractedCount
      });

      item.status = 'completed';
      item.extractedRecordsCount = extractedCount;
      item.parseDurationText = durationText;
      item.processedBytes = item.totalBytes;

      await addAuditLog(
        'upload',
        'رفع واستخراج ملف',
        `تم إضافة ملف: "${item.file.name}" إلى [${item.targetDatabase} - ${item.country}] - استخراج ${extractedCount.toLocaleString('ar-IQ')} سجل خلال ${durationText}`
      );
    } catch (err: any) {
      console.error(`Error parsing file ${item.file.name}:`, err);
      item.status = 'error';
      item.errorMessage = err.message || 'حدث خطأ أثناء معالجة الملف';

      if (fileId !== null) {
        try {
          await db.files.delete(fileId);
          await db.records.where('fileId').equals(fileId).delete();
        } catch (cleanupErr) {
          console.warn('Failed cleanup for corrupt file:', cleanupErr);
        }
      }
    } finally {
      this.notify();

      setTimeout(() => {
        if (this.queue[this.currentActiveIndex]?.status === 'completed' || this.queue[this.currentActiveIndex]?.status === 'error') {
          this.processNextInQueue();
        }
      }, 50);
    }
  }

  private startTimer() {
    this.stopTimer();
    this.timerId = setInterval(() => {
      if (this.currentActiveIndex >= 0 && this.queue[this.currentActiveIndex]) {
        const item = this.queue[this.currentActiveIndex];
        if (item.status === 'processing' && item.startTime) {
          item.elapsedSeconds = Math.floor((Date.now() - item.startTime) / 1000);
          this.notify();
        }
      }
    }, 500);
  }

  private stopTimer() {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  public clearQueue(): void {
    if (!this.isProcessing) {
      this.queue = [];
      this.notify();
    }
  }
}

export const queueManager = new ProcessingQueueManager();
