import Dexie, { Table } from 'dexie';
import {
  StoredFile,
  ExtractedRecord,
  AuditLog,
  DatabaseCategory,
  DeepSearchCriteria,
  CountryRecord,
  GovernorateRecord,
  ScopeType,
  CategoryType
} from '../types/database';

export class IraqDataCenterDB extends Dexie {
  files!: Table<StoredFile, number>;
  records!: Table<ExtractedRecord, number>;
  auditLogs!: Table<AuditLog, number>;
  categories!: Table<DatabaseCategory, number>;
  countries!: Table<CountryRecord, number>;
  governorates!: Table<GovernorateRecord, number>;

  constructor() {
    super('IraqDataEnterpriseV4DB');
    this.version(3).stores({
      files: '++id, fileName, fileSizeBytes, uploadTimestamp, targetDatabase, scope, country',
      records:
        '++id, fileId, category, targetDatabase, scope, country, familyId, serialCode, governorate, firstName, secondName, thirdName, detectedPhone, district, *searchIndex',
      auditLogs: '++id, timestamp, type',
      categories: '++id, name, scope, country',
      countries: '++id, name, isDefault',
      governorates: '++id, country, name'
    });
  }
}

export const db = new IraqDataCenterDB();

// Initial system setup: categories, countries, governorates
export async function ensureDefaultCategories(): Promise<void> {
  const catCount = await db.categories.count();
  if (catCount === 0) {
    const defaultCategories: DatabaseCategory[] = [
      { name: 'قاعدة بيانات العراق', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'آسيا سيل', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'زين العراق', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'كورك تليكوم', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'الرعاية الاجتماعية', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'نقابة الصحفيين', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'مؤسسة السجناء', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'وزارة التربية / الطلاب', scope: 'local', country: 'العراق', isSystem: true },
      { name: 'قاعدة بيانات سوريا', scope: 'global', country: 'سوريا', isSystem: true },
      { name: 'سيريتل', scope: 'global', country: 'سوريا', isSystem: true },
      { name: 'MTN سوريا', scope: 'global', country: 'سوريا', isSystem: true }
    ];
    await db.categories.bulkAdd(defaultCategories);
    await addAuditLog('system', 'تهيئة القطاعات والقواعد', 'تم إنشاء الفئات والقطاعات الأولية للنظام');
  }

  const countryCount = await db.countries.count();
  if (countryCount === 0) {
    const initialCountries: CountryRecord[] = [
      { name: 'العراق', isDefault: true, code: 'IQ' },
      { name: 'سوريا', isDefault: true, code: 'SY' },
      { name: 'مصر', isDefault: true, code: 'EG' },
      { name: 'الأردن', isDefault: true, code: 'JO' },
      { name: 'المملكة العربية السعودية', isDefault: true, code: 'SA' }
    ];
    await db.countries.bulkAdd(initialCountries);
  }

  const govCount = await db.governorates.count();
  if (govCount === 0) {
    const defaultGovs: GovernorateRecord[] = [
      // العراق
      ...['بغداد', 'النجف', 'نينوى', 'البصرة', 'أربيل', 'السليمانية', 'دهوك', 'بابل', 'كربلاء', 'كركوك', 'الأنبار', 'ذي قار', 'ديالي', 'صلاح الدين', 'القادسية', 'ميسان', 'المثنى', 'واسط'].map(name => ({ country: 'العراق', name })),
      // سوريا
      ...['دمشق', 'ريف دمشق', 'حلب', 'حمص', 'حماة', 'اللاذقية', 'طرطوس', 'إدلب', 'دير الزور', 'الحسكة', 'الرقة', 'درعا', 'السويداء', 'القنيطرة'].map(name => ({ country: 'سوريا', name })),
      // مصر
      ...['القاهرة', 'الجيزة', 'الإسكندرية', 'الدقهلية', 'الشرقية', 'القليوبية', 'المنوفية', 'الغربية', 'البحيرة', 'الإسماعيلية', 'أسيوط', 'سوهاج', 'قنا', 'أسوان'].map(name => ({ country: 'مصر', name })),
      // المملكة العربية السعودية
      ...['الرياض', 'مكة المكرمة', 'المدينة المنورة', 'الشرقية', 'القصيم', 'عسير', 'تبوك', 'حائل', 'الجوف', 'جازان', 'نجران', 'الباحة', 'الحدود الشمالية'].map(name => ({ country: 'المملكة العربية السعودية', name })),
      // الأردن
      ...['عمان', 'إربد', 'الزرقاء', 'المفرق', 'السلط', 'الكرك', 'مأدبا', 'جرش', 'عجلون', 'العقبة', 'الطفيلة', 'معان'].map(name => ({ country: 'الأردن', name }))
    ];
    await db.governorates.bulkAdd(defaultGovs);
    await addAuditLog('system', 'تهيئة الخارطة الجغرافية', 'تم تسجيل المحافظات الأولية للدول المعتمدة');
  }
}

// Request persistent storage from browser
export async function initStoragePersistence(): Promise<boolean> {
  if (navigator.storage && navigator.storage.persist) {
    try {
      const isPersisted = await navigator.storage.persist();
      return isPersisted;
    } catch (err) {
      console.warn('Error requesting persistent storage:', err);
      return false;
    }
  }
  return false;
}

export async function checkIsPersisted(): Promise<boolean> {
  if (navigator.storage && navigator.storage.persisted) {
    return await navigator.storage.persisted();
  }
  return false;
}

// Add Audit Log Entry
export async function addAuditLog(
  type: AuditLog['type'],
  action: string,
  details: string
): Promise<void> {
  try {
    const timestamp = new Date().toLocaleString('ar-IQ', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    await db.auditLogs.add({
      timestamp,
      action,
      details,
      type
    });
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}

// Cascade delete file and all its extracted records
export async function deleteFileCascade(fileId: number, fileName: string): Promise<void> {
  await db.transaction('rw', db.files, db.records, db.auditLogs, async () => {
    const recCount = await db.records.where('fileId').equals(fileId).count();
    await db.records.where('fileId').equals(fileId).delete();
    await db.files.delete(fileId);

    await addAuditLog(
      'delete',
      'حذف ملف',
      `تم حذف الملف "${fileName}" وكافة سجلاته المستخرجة (${recCount.toLocaleString('ar-IQ')} سجل)`
    );
  });
}

// Constants
export const TELECOM_CATEGORIES: CategoryType[] = [
  'asia',
  'zain',
  'korek',
  'syriatel',
  'mtn',
  'international'
];

// Add batch of records in chunked transactions
export async function addRecordsBatch(records: ExtractedRecord[]): Promise<void> {
  if (records.length === 0) return;
  await db.records.bulkPut(records);
}

// Fetch family members by Family ID
export async function fetchFamilyMembers(
  familyId: string,
  country = 'العراق'
): Promise<ExtractedRecord[]> {
  if (!familyId || familyId.trim() === '') return [];
  const cleanId = familyId.trim().toLowerCase();

  const results = await db.records
    .where('familyId')
    .equals(cleanId)
    .or('serialCode')
    .equals(cleanId)
    .filter((rec) => !rec.country || rec.country === country)
    .toArray();

  if (results.length === 0) {
    return await db.records
      .filter(
        (rec) =>
          (!rec.country || rec.country === country) &&
          rec.data &&
          Object.values(rec.data).some(
            (v) => String(v).trim().toLowerCase() === cleanId
          )
      )
      .toArray();
  }

  await addAuditLog(
    'family',
    'جلب العائلة',
    `تم استعلام عائلة رقم [${familyId}] - عُثر على ${results.length} أفراد`
  );

  return results;
}

// Perform Governorate Name Search
export async function searchByGovernorate(
  nameQuery: string,
  governorate: string,
  country = 'العراق',
  scope: ScopeType = 'local',
  isIntensive = false
): Promise<{ records: ExtractedRecord[]; matchCount: number }> {
  const cleanQuery = nameQuery.trim().toLowerCase();
  if (!cleanQuery) return { records: [], matchCount: 0 };

  const nameParts = cleanQuery.split(/\s+/).filter(Boolean);
  const firstPart = nameParts[0];

  let matches = await db.records
    .where('searchIndex')
    .startsWith(firstPart)
    .limit(1000)
    .toArray();

  if (matches.length === 0) {
    matches = await db.records
      .where('firstName')
      .startsWith(firstPart)
      .limit(1000)
      .toArray();
  }

  const results = matches
    .filter((rec) => {
      if (rec.country && rec.country !== country) return false;

      // Strict View Isolation: Exclude Telecom Carriers from demographic view when Intensive Search is OFF
      if (!isIntensive && TELECOM_CATEGORIES.includes(rec.category)) {
        return false;
      }

      if (governorate && governorate !== 'جميع المحافظات' && governorate !== 'الكل') {
        const recGov = (
          rec.governorate ||
          rec.data?.['المحافظة'] ||
          rec.data?.['governorate'] ||
          ''
        ).toLowerCase();
        if (
          !recGov.includes(governorate.toLowerCase()) &&
          !rec.searchIndex.some((t) => t.includes(governorate.toLowerCase()))
        ) {
          return false;
        }
      }

      const textCorpus = [
        rec.firstName,
        rec.secondName,
        rec.thirdName,
        ...Object.values(rec.data || {}).map(String)
      ]
        .join(' ')
        .toLowerCase();

      return nameParts.every((part) => textCorpus.includes(part));
    })
    .slice(0, 500);

  await addAuditLog(
    'search',
    isIntensive ? 'استعلام أسماء (بحث مكثف)' : 'استعلام أسماء (معزول)',
    `بحث في [${governorate || 'جميع المحافظات'}] عن "${nameQuery}" - ${results.length} نتائج`
  );

  return { records: results, matchCount: results.length };
}

// Country & Governorate CRUD helper functions
export async function getCountries(): Promise<CountryRecord[]> {
  return await db.countries.toArray();
}

export async function addCountry(name: string, code = ''): Promise<void> {
  const clean = name.trim();
  if (!clean) return;
  const existing = await db.countries.where('name').equals(clean).first();
  if (!existing) {
    await db.countries.add({ name: clean, isDefault: false, code });
    await addAuditLog('system', 'إنشاء دولة جديدة', `تمت إضافة دولة جديدة للنظام: [${clean}]`);
  }
}

export async function deleteCountry(id: number): Promise<void> {
  const c = await db.countries.get(id);
  if (c && !c.isDefault) {
    await db.countries.delete(id);
    await db.governorates.where('country').equals(c.name).delete();
    await addAuditLog('system', 'حذف دولة', `تم حذف الدولة [${c.name}] وكافة محافظاتها المخصصة`);
  }
}

export async function getGovernorates(countryName: string): Promise<GovernorateRecord[]> {
  return await db.governorates.where('country').equals(countryName).toArray();
}

export async function addGovernorate(countryName: string, name: string): Promise<void> {
  const clean = name.trim();
  if (!clean) return;
  const existing = await db.governorates
    .where({ country: countryName, name: clean })
    .first();
  if (!existing) {
    await db.governorates.add({ country: countryName, name: clean });
    await addAuditLog('system', 'إضافة محافظة', `تمت إضافة محافظة جديدة [${clean}] لـ [${countryName}]`);
  }
}

export async function deleteGovernorate(id: number): Promise<void> {
  const g = await db.governorates.get(id);
  if (g) {
    await db.governorates.delete(id);
    await addAuditLog('system', 'حذف محافظة', `تم حذف المحافظة [${g.name}] من [${g.country}]`);
  }
}

// Perform Deep Search (Multi-criteria)
export async function searchDeep(
  criteria: DeepSearchCriteria,
  country = 'العراق',
  isIntensive = false
): Promise<{ records: ExtractedRecord[]; matchCount: number }> {
  let query = db.records.where('searchIndex');

  const firstTerm =
    criteria.firstName?.toLowerCase() ||
    criteria.governorate?.toLowerCase() ||
    criteria.occupation?.toLowerCase();

  let matches = firstTerm
    ? await query.startsWith(firstTerm).limit(1000).toArray()
    : await db.records.limit(1000).toArray();

  const results = matches
    .filter((rec) => {
      if (rec.country && rec.country !== country) return false;

      if (!isIntensive && TELECOM_CATEGORIES.includes(rec.category)) {
        return false;
      }

      if (
        criteria.governorate &&
        criteria.governorate !== 'جميع المحافظات' &&
        criteria.governorate !== 'الكل'
      ) {
        const gov = (rec.governorate || rec.data?.['المحافظة'] || '').toLowerCase();
        if (
          !gov.includes(criteria.governorate.toLowerCase()) &&
          !rec.searchIndex.some((s) => s.includes(criteria.governorate!.toLowerCase()))
        ) {
          return false;
        }
      }

      const corpus = [
        rec.firstName,
        rec.secondName,
        rec.thirdName,
        rec.age,
        rec.birthYear,
        rec.occupation,
        rec.district,
        ...Object.values(rec.data || {}).map(String)
      ]
        .join(' ')
        .toLowerCase();

      if (criteria.firstName && !corpus.includes(criteria.firstName.toLowerCase())) {
        return false;
      }
      if (criteria.secondName && !corpus.includes(criteria.secondName.toLowerCase())) {
        return false;
      }
      if (criteria.thirdName && !corpus.includes(criteria.thirdName.toLowerCase())) {
        return false;
      }
      if (criteria.age && !corpus.includes(criteria.age.toLowerCase())) {
        return false;
      }
      if (criteria.birthYear && !corpus.includes(criteria.birthYear.toLowerCase())) {
        return false;
      }
      if (criteria.occupation && !corpus.includes(criteria.occupation.toLowerCase())) {
        return false;
      }
      if (criteria.district && !corpus.includes(criteria.district.toLowerCase())) {
        return false;
      }

      return true;
    })
    .slice(0, 500);

  await addAuditLog(
    'search',
    isIntensive ? 'البحث العميق (بحث مكثف)' : 'البحث العميق (معزول)',
    `بحث مركب عن: ${JSON.stringify(criteria)} - عُثر على ${results.length} نتائج`
  );

  return { records: results, matchCount: results.length };
}

// Perform Phone Search
export async function searchByPhone(
  normalizedPhone: string,
  isIntensive = false
): Promise<{ records: ExtractedRecord[]; matchCount: number }> {
  const clean = normalizedPhone.replace(/\D/g, '');
  if (!clean) return { records: [], matchCount: 0 };

  let results = await db.records
    .where('detectedPhone')
    .startsWith(clean)
    .or('searchIndex')
    .equals(clean)
    .limit(300)
    .toArray();

  if (results.length === 0) {
    results = await db.records
      .where('searchIndex')
      .startsWith(clean)
      .limit(300)
      .toArray();
  }

  // Strict View Isolation: Exclude non-telecoms if NOT intensive, or vice versa
  if (!isIntensive) {
    results = results.filter((rec) => TELECOM_CATEGORIES.includes(rec.category));
  }

  await addAuditLog(
    'search',
    isIntensive ? 'بحث هاتف (بحث مكثف)' : 'بحث هاتف (معزول)',
    `استعلام رقم [${normalizedPhone}] - عُثر على ${results.length} سجلات`
  );

  return { records: results, matchCount: results.length };
}

// Intensive Search Dossier Data Structures
export interface DossierGroup {
  sectorName: string;
  category: CategoryType | 'master' | 'social' | 'pension' | 'education' | 'security' | 'other';
  records: ExtractedRecord[];
}

export interface IntelligenceDossier {
  queryTerm: string;
  fullName?: string;
  phone?: string;
  familyId?: string;
  governorate?: string;
  groups: DossierGroup[];
  totalMatches: number;
}

// Telegram-Bot Style Unified Intelligence Dossier Aggregation
export async function searchIntensiveDossier(
  term: string,
  country = 'العراق'
): Promise<IntelligenceDossier> {
  const clean = term.trim().toLowerCase();
  if (!clean) {
    return { queryTerm: term, groups: [], totalMatches: 0 };
  }

  const cleanDigits = clean.replace(/\D/g, '');
  let rawHits: ExtractedRecord[] = [];

  if (cleanDigits.length >= 5) {
    const phoneHits = await db.records
      .where('detectedPhone')
      .startsWith(cleanDigits)
      .or('familyId')
      .equals(clean)
      .or('serialCode')
      .equals(clean)
      .limit(500)
      .toArray();

    rawHits.push(...phoneHits);
  }

  const indexHits = await db.records
    .where('searchIndex')
    .startsWith(clean.split(/\s+/)[0])
    .limit(500)
    .toArray();

  rawHits.push(...indexHits);

  const hitMap = new Map<number, ExtractedRecord>();
  rawHits.forEach((rec) => {
    if (rec.id && (!rec.country || rec.country === country)) {
      hitMap.set(rec.id, rec);
    }
  });

  const allRecords = Array.from(hitMap.values());

  const sectorMap: Record<string, DossierGroup> = {
    telecom: { sectorName: '📞 سجلات الاتصالات والهواتف', category: 'zain', records: [] },
    civil: { sectorName: '🪪 السجل المدني والهوية الموحدة', category: 'master' as any, records: [] },
    social: { sectorName: '🏛️ الرعاية الاجتماعية والخدمات', category: 'social' as any, records: [] },
    employment: { sectorName: '💼 الوظائف والتعليم والتقاعد', category: 'pension' as any, records: [] },
    security: { sectorName: '🛡️ السجلات الأمنية والقيود', category: 'security' as any, records: [] },
    other: { sectorName: '📑 قواعد البيانات العامة والقطاعات', category: 'other', records: [] }
  };

  let topFullName: string | undefined;
  let topPhone: string | undefined;
  let topFamilyId: string | undefined;
  let topGov: string | undefined;

  allRecords.forEach((rec) => {
    if (!topFullName && rec.firstName) {
      topFullName = [rec.firstName, rec.secondName, rec.thirdName].filter(Boolean).join(' ');
    }
    if (!topPhone && rec.detectedPhone) topPhone = rec.detectedPhone;
    if (!topFamilyId && rec.familyId) topFamilyId = rec.familyId;
    if (!topGov && rec.governorate) topGov = rec.governorate;

    const dbName = (rec.targetDatabase || '').toLowerCase();
    const cat = rec.category;

    if (TELECOM_CATEGORIES.includes(cat) || dbName.includes('آسيا') || dbName.includes('زين') || dbName.includes('كورك')) {
      sectorMap.telecom.records.push(rec);
    } else if (dbName.includes('رعاية') || dbName.includes('اجتماع')) {
      sectorMap.social.records.push(rec);
    } else if (dbName.includes('تربية') || dbName.includes('طلاب') || dbName.includes('خريج') || dbName.includes('تقاعد') || dbName.includes('صحفيين')) {
      sectorMap.employment.records.push(rec);
    } else if (dbName.includes('سجناء') || dbName.includes('شهداء') || dbName.includes('أمن')) {
      sectorMap.security.records.push(rec);
    } else if (dbName.includes('عراق') || dbName.includes('موحدة') || dbName.includes('سجل')) {
      sectorMap.civil.records.push(rec);
    } else {
      sectorMap.other.records.push(rec);
    }
  });

  const activeGroups = Object.values(sectorMap).filter((g) => g.records.length > 0);

  await addAuditLog(
    'search',
    'استعلام الملف الاستخباري الشامل (البحث المكثف)',
    `تم إنتاج ملف تعريف شامل لـ [${term}] - إجمالي المطابقات: ${allRecords.length} في ${activeGroups.length} قطاعات`
  );

  return {
    queryTerm: term,
    fullName: topFullName,
    phone: topPhone,
    familyId: topFamilyId,
    governorate: topGov,
    groups: activeGroups,
    totalMatches: allRecords.length
  };
}

// Atomic update for stored file records in live file editor
export async function updateFileRecords(
  fileId: number,
  updatedRecords: ExtractedRecord[],
  deletedRecordIds: number[]
): Promise<void> {
  await db.transaction('rw', db.files, db.records, db.auditLogs, async () => {
    if (deletedRecordIds.length > 0) {
      await db.records.bulkDelete(deletedRecordIds);
    }
    if (updatedRecords.length > 0) {
      await db.records.bulkPut(updatedRecords);
    }

    const currentCount = await db.records.where('fileId').equals(fileId).count();
    await db.files.update(fileId, { recordCount: currentCount });

    await addAuditLog(
      'system',
      'تعديل ملف مخزن',
      `تم تحديث سجلات الملف [ID: ${fileId}] - الإجمالي الجديد: ${currentCount} سجل`
    );
  });
}

// Convert Arabic-Indic Digits to Latin/ASCII Digits
export function normalizeArabicDigits(str: string): string {
  if (!str) return '';
  return str
    .replace(/[٠0]/g, '0')
    .replace(/[١1]/g, '1')
    .replace(/[٢2]/g, '2')
    .replace(/[٣3]/g, '3')
    .replace(/[٤4]/g, '4')
    .replace(/[٥5]/g, '5')
    .replace(/[٦6]/g, '6')
    .replace(/[٧7]/g, '7')
    .replace(/[٨8]/g, '8')
    .replace(/[٩9]/g, '9');
}

// Helper to format byte counts into human-readable strings
export function formatBytes(bytes: number): string {
  if (bytes === 0 || isNaN(bytes)) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Helper to format duration
export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const totalSec = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSec / 60);
  const seconds = totalSec % 60;
  if (minutes === 0) return `${seconds}s`;
  return `${minutes}m ${seconds}s`;
}
