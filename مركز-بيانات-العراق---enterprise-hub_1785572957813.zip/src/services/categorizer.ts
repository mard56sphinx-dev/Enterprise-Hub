import { CategoryType } from '../types/database';
import { parseNERFromRecord, NERResult } from './nerEngine';

export interface CategorizationResult extends NERResult {}

// Extract phone numbers and categorize based on operator patterns & NER
export function categorizeRecord(
  data: Record<string, any>,
  targetDatabase?: string
): CategorizationResult {
  return parseNERFromRecord(data, targetDatabase);
}

export function extractDemographics(data: Record<string, any>): NERResult {
  return parseNERFromRecord(data);
}

// Generate lowercase array of terms for fast search filtering in IndexedDB
export function buildSearchIndex(data: Record<string, any>): string[] {
  const terms = new Set<string>();
  Object.values(data).forEach((val) => {
    if (val !== null && val !== undefined) {
      const s = String(val).toLowerCase().trim();
      if (s) {
        terms.add(s);
        // Also split by common delimiters to index individual tokens/words
        const tokens = s.split(/[\s,;:|\-\/]+/);
        tokens.forEach((t) => {
          if (t.length >= 2) terms.add(t);
        });
      }
    }
  });
  return Array.from(terms);
}

