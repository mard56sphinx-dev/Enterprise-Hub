import React from 'react';
import { StoredFile } from '../types/database';
import { AlertTriangle, Trash2, X } from 'lucide-react';

interface DeleteConfirmationModalProps {
  file: StoredFile | null;
  onConfirm: () => void;
  onCancel: () => void;
  isDeleting: boolean;
}

export const DeleteConfirmationModal: React.FC<DeleteConfirmationModalProps> = ({
  file,
  onConfirm,
  onCancel,
  isDeleting
}) => {
  if (!file) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#161b22] border border-[#30363d] rounded-2xl max-w-md w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          onClick={onCancel}
          disabled={isDeleting}
          className="absolute left-4 top-4 text-[#8b949e] hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-full bg-[#da3633]/20 border border-[#da3633]/40 text-[#f85149] flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-6 h-6" />
        </div>

        <h3 className="text-lg font-bold text-[#f85149] text-center mb-2">
          تأكيد حذف الملف نهائياً
        </h3>

        <div className="bg-[#0d1117] border border-[#30363d] rounded-xl p-3.5 mb-5 text-xs text-[#c9d1d9] space-y-2">
          <p className="text-center font-medium">
            هل أنت متأكد من حذف الملف التالية بياناته بشكل نهائي من التخزين؟
          </p>

          <div className="pt-2 border-t border-[#30363d] space-y-1 font-mono text-[11px]">
            <div className="flex justify-between">
              <span className="text-[#8b949e]">اسم الملف:</span>
              <span className="font-bold text-[#58a6ff] truncate max-w-[200px]">
                {file.fileName}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8b949e]">السجلات المرتبطة:</span>
              <span className="font-bold text-[#f85149]">
                {(file.recordCount || 0).toLocaleString('ar-IQ')} سجل
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8b949e]">حجم الملف:</span>
              <span className="text-[#c9d1d9]">{file.fileSize}</span>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onConfirm}
            disabled={isDeleting}
            className="flex-1 py-2.5 px-4 bg-[#da3633] hover:bg-[#f85149] text-white rounded-xl text-xs font-bold transition-all disabled:opacity-50 flex justify-center items-center gap-2 shadow-lg shadow-red-500/10"
          >
            <Trash2 className="w-4 h-4" />
            <span>{isDeleting ? 'جاري الحذف...' : 'نعم، تأكيد الحذف النهائية'}</span>
          </button>

          <button
            onClick={onCancel}
            disabled={isDeleting}
            className="py-2.5 px-5 bg-[#21262d] border border-[#30363d] text-[#c9d1d9] hover:text-white hover:bg-[#30363d] rounded-xl text-xs font-bold transition-all"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};
