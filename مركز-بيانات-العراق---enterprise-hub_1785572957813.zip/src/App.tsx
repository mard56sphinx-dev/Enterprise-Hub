import React, { useState, useEffect, useCallback } from 'react';
import { StoredFile, ExtractedRecord, QueueItem, ProcessingMetrics, ScopeType } from './types/database';
import {
  db,
  initStoragePersistence,
  deleteFileCascade,
  formatBytes,
  ensureDefaultCategories
} from './services/db';
import { queueManager } from './services/queueManager';

import { Header } from './components/Header';
import { StatsGrid } from './components/StatsGrid';
import { ProgressPanel } from './components/ProgressPanel';
import { GovernorateGrid } from './components/GovernorateGrid';
import { GovernorateSearchModal } from './components/GovernorateSearchModal';
import { DeepSearchModal } from './components/DeepSearchModal';
import { UnifiedPhoneSearch } from './components/UnifiedPhoneSearch';
import { AuditJournal } from './components/AuditJournal';
import { SystemSettings } from './components/SystemSettings';
import { UploadRoutingModal } from './components/UploadRoutingModal';
import { DoubleVerificationDeleteModal } from './components/DoubleVerificationDeleteModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<'search' | 'phone' | 'audit' | 'admin'>('search');
  const [scope, setScope] = useState<ScopeType>('local');
  const [selectedCountry, setSelectedCountry] = useState('العراق');
  const [countries, setCountries] = useState(['العراق', 'سوريا', 'مصر', 'الأردن', 'المملكة العربية السعودية']);
  const [categories, setCategories] = useState<string[]>([]);

  const [isPersisted, setIsPersisted] = useState(false);
  const [files, setFiles] = useState<StoredFile[]>([]);
  const [records, setRecords] = useState<ExtractedRecord[]>([]);

  // Queue state
  const [queueMetrics, setQueueMetrics] = useState<ProcessingMetrics | null>(null);
  const [queueItems, setQueueItems] = useState<QueueItem[]>([]);

  // Search Modals
  const [selectedGovForSearch, setSelectedGovForSearch] = useState<string | null>(null);
  const [showDeepSearch, setShowDeepSearch] = useState(false);

  // Upload Routing Modal
  const [pendingUploadFiles, setPendingUploadFiles] = useState<File[] | null>(null);

  // Delete Verification Modal
  const [fileToDelete, setFileToDelete] = useState<StoredFile | null>(null);

  // System Stats
  const [stats, setStats] = useState({
    totalRecords: 0,
    zainCount: 0,
    asiaCount: 0,
    korekCount: 0,
    localDbCount: 0,
    globalDbCount: 0,
    filesCount: 0,
    storageUsageText: '0 Bytes'
  });

  // Load Categories & Database Data
  const loadDatabaseData = useCallback(async () => {
    try {
      await ensureDefaultCategories();

      const allCountries = await db.countries.toArray();
      if (allCountries.length > 0) {
        setCountries(allCountries.map((c) => c.name));
      }

      const allCategories = await db.categories.toArray();
      setCategories(allCategories.map((c) => c.name));

      const allFiles = await db.files.toArray();
      const allRecords = await db.records.toArray();

      setFiles(allFiles);
      setRecords(allRecords);

      let zain = 0;
      let asia = 0;
      let korek = 0;
      let localDb = 0;
      let globalDb = 0;
      let totalBytes = 0;

      allFiles.forEach((f) => {
        totalBytes += f.fileSizeBytes || 0;
      });

      allRecords.forEach((r) => {
        if (r.category === 'zain') zain++;
        else if (r.category === 'asia') asia++;
        else if (r.category === 'korek') korek++;

        if (r.scope === 'local') localDb++;
        else if (r.scope === 'global') globalDb++;
      });

      setStats({
        totalRecords: allRecords.length,
        zainCount: zain,
        asiaCount: asia,
        korekCount: korek,
        localDbCount: localDb,
        globalDbCount: globalDb,
        filesCount: allFiles.length,
        storageUsageText: formatBytes(totalBytes)
      });
    } catch (err) {
      console.error('Error loading database data:', err);
    }
  }, []);

  // Initialize DB & Persistence
  useEffect(() => {
    const init = async () => {
      const persisted = await initStoragePersistence();
      setIsPersisted(persisted);
      await loadDatabaseData();
    };
    init();
  }, [loadDatabaseData]);

  const handleRequestPersistence = async () => {
    const p = await initStoragePersistence();
    setIsPersisted(p);
  };

  // Subscribe to Queue Manager
  useEffect(() => {
    const unsubscribe = queueManager.subscribe((metrics, items) => {
      setQueueMetrics(metrics);
      setQueueItems(items);

      const hasCompletedRecently = items.some(
        (i) => i.status === 'completed' || i.status === 'error'
      );
      if (hasCompletedRecently) {
        loadDatabaseData();
      }
    });
    return unsubscribe;
  }, [loadDatabaseData]);

  // Add Custom Country
  const handleAddCountry = () => {
    const newCountry = prompt('أدخل اسم الدولة الجديدة المضافة للنطاق العالمي:');
    if (newCountry && newCountry.trim()) {
      const clean = newCountry.trim();
      if (!countries.includes(clean)) {
        setCountries([...countries, clean]);
        setSelectedCountry(clean);
        setScope('global');
      }
    }
  };

  // Add Custom Category/Database
  const handleAddNewCategory = async (catName: string) => {
    try {
      await db.categories.add({
        name: catName,
        scope,
        country: selectedCountry
      });
      await loadDatabaseData();
    } catch (err) {
      console.error('Failed to create custom category:', err);
    }
  };

  // Trigger Upload Routing Modal
  const handleUploadSelect = (selectedFiles: File[]) => {
    if (!selectedFiles || selectedFiles.length === 0) return;
    setPendingUploadFiles(selectedFiles);
  };

  // Confirm Upload with Routing Destination
  const handleConfirmUploadRouting = (
    targetDatabase: string,
    targetScope: ScopeType,
    targetCountry: string
  ) => {
    if (pendingUploadFiles) {
      queueManager.enqueueFiles(
        pendingUploadFiles,
        targetDatabase,
        targetScope,
        targetCountry
      );
      setPendingUploadFiles(null);
      setActiveTab('admin');
    }
  };

  // Delete File Action
  const handleConfirmDeleteFile = async () => {
    if (!fileToDelete || !fileToDelete.id) return;
    try {
      await deleteFileCascade(fileToDelete.id, fileToDelete.fileName);
      setFileToDelete(null);
      await loadDatabaseData();
    } catch (err) {
      console.error('Error deleting file:', err);
    }
  };

  const activeQueueCount = queueItems.filter(
    (i) => i.status === 'pending' || i.status === 'processing'
  ).length;

  return (
    <div className="min-h-screen bg-[#0d1117] text-[#c9d1d9] flex flex-col font-sans dir-rtl select-none">
      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        scope={scope}
        setScope={setScope}
        selectedCountry={selectedCountry}
        setSelectedCountry={setSelectedCountry}
        countries={countries}
        onAddCountry={handleAddCountry}
        isPersisted={isPersisted}
        activeQueueCount={activeQueueCount}
      />

      {/* Main Content View */}
      <main className="flex-1 max-w-[1400px] w-full mx-auto p-4 sm:p-6 flex flex-col">
        {/* Stats Grid Overview */}
        <StatsGrid
          totalRecords={stats.totalRecords}
          zainCount={stats.zainCount}
          asiaCount={stats.asiaCount}
          korekCount={stats.korekCount}
          localDbCount={stats.localDbCount}
          globalDbCount={stats.globalDbCount}
          filesCount={stats.filesCount}
          storageUsageText={stats.storageUsageText}
        />

        {/* Queue Progress Panel */}
        <ProgressPanel metrics={queueMetrics} queueItems={queueItems} />

        {/* Tab 1: Governorate Search Grid */}
        {activeTab === 'search' && (
          <GovernorateGrid
            country={selectedCountry}
            onSelectGovernorate={(gov) => setSelectedGovForSearch(gov)}
            onOpenDeepSearch={() => setShowDeepSearch(true)}
          />
        )}

        {/* Tab 2: Unified Phone Number Search */}
        {activeTab === 'phone' && (
          <UnifiedPhoneSearch country={selectedCountry} />
        )}

        {/* Tab 3: System Audit Journal */}
        {activeTab === 'audit' && <AuditJournal />}

        {/* Tab 4: Centralized System Settings */}
        {activeTab === 'admin' && (
          <SystemSettings
            files={files}
            onUploadSelect={handleUploadSelect}
            onRequestDelete={(file) => setFileToDelete(file)}
            isPersisted={isPersisted}
            onRequestPersistence={handleRequestPersistence}
          />
        )}
      </main>

      {/* Governorate Search Modal */}
      {selectedGovForSearch && (
        <GovernorateSearchModal
          governorate={selectedGovForSearch}
          country={selectedCountry}
          onClose={() => setSelectedGovForSearch(null)}
        />
      )}

      {/* Deep Search Engine Modal */}
      {showDeepSearch && (
        <DeepSearchModal
          country={selectedCountry}
          onClose={() => setShowDeepSearch(false)}
        />
      )}

      {/* File Upload Destination & Routing Modal */}
      {pendingUploadFiles && (
        <UploadRoutingModal
          files={pendingUploadFiles}
          categories={categories}
          countries={countries}
          scope={scope}
          selectedCountry={selectedCountry}
          onConfirm={handleConfirmUploadRouting}
          onCancel={() => setPendingUploadFiles(null)}
          onAddNewCategory={handleAddNewCategory}
        />
      )}

      {/* Double Verification Deletion Modal */}
      {fileToDelete && (
        <DoubleVerificationDeleteModal
          file={fileToDelete}
          onConfirm={handleConfirmDeleteFile}
          onCancel={() => setFileToDelete(null)}
        />
      )}
    </div>
  );
}
